# To-do list

A Pen created on CodePen.io. Original URL: [https://codepen.io/cassie-codes/pen/pYwXwb](https://codepen.io/cassie-codes/pen/pYwXwb).

To do list with plain JS to work out the hurdles before re-making with Vue.js

buttons totes nicked from this *amazing* pen https://codepen.io/nopr/pen/AfHin